## Automatic position of the dropdown panel

1. Open a dropdown located in the corner of the page.
2. Check if the panel shows up fully visible in the viewport.
3. Repeat for the rest of dropdowns. Panels should appear above, below, right and left to the button.
