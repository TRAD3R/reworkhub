## Icons with inline SVG

### Sizing
1. First icon should be small and dark.
1. Second icon should be medium and dark.
1. Third icon should be large and dark.

## Colors
1. First icon should be small and red.
1. Second icon should be small and blue, just like text around.

## Dirtiness
1. First icon should be large and green.

## ViewBox
1. First icon should be large and green, same as the previous one.
