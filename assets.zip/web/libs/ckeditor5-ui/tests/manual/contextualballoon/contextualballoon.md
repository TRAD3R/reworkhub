1. Select some text in the middle of the content - contextual toolbar should show up.
2. Click link icon in the contextual toolbar - link balloon should open at the position as contextual toolbar.
3. Close link balloon (Esc press or Cancel button) - contextual toolbar should show up.
4. Repeat this for backward selection.
