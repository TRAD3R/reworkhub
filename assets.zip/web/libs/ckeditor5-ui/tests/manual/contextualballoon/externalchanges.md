## Link panel opened from BalloonToolbar should be updated on external changes.

### Create #1:

1. Click **Start external changes** then quickly select some text which is not a link yet and press the Link button in the toolbar (the link editing balloon should show up).
2. Observe if the balloon remains attached to the selection.
3. Repeat this for a backward selection.

### Create #2:

1. Click **Start external changes** then quickly select text to wrap place where external changes will be inserted e.g `HE[RE -> The spe]cification` then open link click by link icon in contextual toolbar.
2. Observe if the balloon remains attached to the selection.
3. Repeat this for a backward selection.

### Delete:

1. Click **Start external changes** then quickly select some text in the **second paragraph** press the Link button in the contextual toolbar (the link editing balloon should show up).
2. Observe if the balloon remains attached to the the selection after the removal.
