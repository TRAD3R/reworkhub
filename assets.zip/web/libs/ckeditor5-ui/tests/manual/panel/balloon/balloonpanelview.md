## `BalloonPanelView` and `defaultPositions`

1. A number of green rectangles should be displayed in the page.
2. Each rectangle should have a panel attached.
3. Make sure the description in each panel matches the location of the panel.
