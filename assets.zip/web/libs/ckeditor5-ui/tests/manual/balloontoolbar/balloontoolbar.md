## Contextual toolbar demo

1. Create a non–collapsed selection.
2. Create another non–collapsed selection but in another direction.
3. For each selection, a contextual toolbar should appear and the beginning/end of the selection, duplicating main editor toolbar.
4. Toolbar should not display when selection is placed in the first block element.
