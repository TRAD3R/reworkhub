﻿/*
 Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","sv",{title:"UI Färgväljare",options:"Färgalternativ",highlight:"Markera",selected:"Vald färg",predefined:"Fördefinierade färguppsättningar",config:"Klistra in den här strängen i din config.js-fil"});